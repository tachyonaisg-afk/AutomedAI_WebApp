import React, { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Layout from "../components/Layout/Layout";
import styled from "styled-components";
import { Plus, Minus, CreditCard, Camera, X } from "lucide-react";
import AadhaarScanner from "../components/shared/AadhaarScanner";
import usePageTitle from "../hooks/usePageTitle";
import apiService from "../services/api/apiService";
import API_ENDPOINTS from "../services/api/endpoints";
import Select from "react-select";
import paymentQR from "../assets/paymentupi.jpeg";
import AadhaarOCRScanner from "../components/shared/AadhaarOCRScanner";
import api from "../services/api";

const RegistrationContainer = styled.div`
  display: flex;
  flex-direction: column;
//   gap: 24px;
`;

const ProgressIndicator = styled.div`
  display: flex;
  flex-direction: column;
//   gap: 12px;
  margin-bottom: 10px;
`;

const ProgressStepsContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
`;

const ProgressStep = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex: 1;
  position: relative;
`;

const StepLabel = styled.span`
  font-size: 14px;
  font-weight: 500;
  color: ${(props) => (props.active ? "#4a90e2" : "#999999")};
  white-space: nowrap;
  cursor: default;
  transition: color 0.2s;
  margin-bottom: 12px;
`;

const ProgressBarContainer = styled.div`
  width: 100%;
  height: 8px;
  background-color: #e3f2fd;
  border-radius: 4px;
  overflow: hidden;
  position: relative;
`;

const ProgressBarFill = styled.div`
  height: 100%;
  background-color: #4a90e2;
  border-radius: 4px;
  transition: width 0.3s ease;
  width: ${(props) => {
        if (props.currentStep === 1) return "50%";
        // if (props.currentStep === 2) return "66.66%";
        if (props.currentStep === 2) return "100%";
        // if (props.currentStep === 4) return "100%";
        return "0%";
    }};
`;

const FormSection = styled.div`
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  padding: 24px;
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

const SectionTitle = styled.h2`
  font-size: 18px;
  font-weight: 600;
  color: #333333;
  margin: 0;
  padding-bottom: 12px;
  border-bottom: 1px solid #e0e0e0;
`;

const FormGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  grid-column: ${(props) => (props.fullWidth ? "1 / -1" : "auto")};
`;

const FormLabel = styled.label`
  font-size: 14px;
  font-weight: 500;
  color: #333333;
`;

const RequiredAsterisk = styled.span`
  color: #dc2626;
  margin-left: 4px;
`;

const FormInput = styled.input`
  padding: 10px 12px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  font-size: 14px;
  color: #333333;
  outline: none;
  transition: border-color 0.2s;

  &:focus {
    border-color: #4a90e2;
  }

  &::placeholder {
    color: #999999;
  }

  &:disabled {
    background-color: #f5f5f5;
    color: #666666;
    cursor: not-allowed;
    border-color: #d0d0d0;
  }
`;

const FormSelect = styled.select`
  padding: 10px 12px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  font-size: 14px;
  color: #333333;
  background-color: #ffffff;
  outline: none;
  cursor: pointer;
  transition: border-color 0.2s;
  appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23999' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 12px center;
  padding-right: 32px;

  &:focus {
    border-color: #4a90e2;
  }

  &:disabled {
    background-color: #f5f5f5;
    color: #666666;
    cursor: not-allowed;
    border-color: #d0d0d0;
  }
`;

const HelperText = styled.p`
  font-size: 12px;
  color: #999999;
  margin: -4px 0 0 0;
`;

const TextArea = styled.textarea`
  padding: 10px 12px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  font-size: 14px;
  color: #333333;
  outline: none;
  transition: border-color 0.2s;
  resize: vertical;
  min-height: 100px;
  font-family: inherit;

  &:focus {
    border-color: #4a90e2;
  }

  &::placeholder {
    color: #999999;
  }
`;

const ActionButtons = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 16px;
  margin-top: 8px;
`;

const NextButton = styled.button`
  background-color: #4a90e2;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 12px 32px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;

  &:hover {
    background-color: #357abd;
  }
`;

const BackButton = styled.button`
  background-color: #f5f5f5;
  color: #333333;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 12px 32px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;

  &:hover {
    background-color: #e8e8e8;
  }
`;

const ItemsSection = styled.div`
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-top: 8px;
`;

const ItemsHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
`;

const ItemsTitle = styled.h2`
  font-size: 18px;
  font-weight: 600;
  color: #333333;
  margin: 0;
`;

const ItemButtons = styled.div`
  display: flex;
  gap: 8px;
`;

const IconButton = styled.button`
  width: 32px;
  height: 32px;
  border-radius: 6px;
  border: 1px solid #e0e0e0;
  background-color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s;

  &:hover {
    background-color: #f5f5f5;
    border-color: #4a90e2;
  }

  svg {
    width: 16px;
    height: 16px;
    color: #333333;
  }
`;

const ItemsTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 16px;
`;

const TableHead = styled.thead`
  background-color: #f8f9fa;
`;

const TableRow = styled.tr`
  border-bottom: 1px solid #e0e0e0;

  &:last-child {
    border-bottom: none;
  }
`;

const TableHeader = styled.th`
  padding: 12px;
  text-align: left;
  font-size: 12px;
  font-weight: 600;
  color: #666666;
  text-transform: uppercase;

  &:first-child {
    padding-left: 16px;
    width: 50px;
  }

  &:nth-child(3) {
    width: 400px; /* Item Name */
  }

  &:nth-child(4) {
    width: 100px;
  }

  &:nth-child(5) {
    width: 120px;
  }

  &:nth-child(6) {
    width: 140px;
  }

  &:last-child {
    width: 10px;
    text-align: right;
    padding-right: 5px;
  }
`;

const TableBody = styled.tbody``;

const TableCell = styled.td`
  padding: 12px;
  font-size: 14px;
  color: #333333;

  &:first-child {
    padding-left: 16px;
    color: #666666;
  }

  &:last-child {
    text-align: right;
    padding-right: 16px;
    font-weight: 500;
  }
`;

const ItemInput = styled.input`
  width: 100%;
  padding: 6px 8px;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  font-size: 14px;
  color: #333333;
  outline: none;

  &:focus {
    border-color: #4a90e2;
  }
`;

const ItemFooter = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background-color: #f8f9fa;
  border-radius: 6px;
`;

const FooterItem = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #333333;
`;

const FooterLabel = styled.span`
  font-weight: 500;
`;

const FooterValue = styled.span`
  font-weight: 600;
`;

const DiscountInput = styled.input`
  width: 80px;
  padding: 6px 8px;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  font-size: 14px;
  color: #333333;
  outline: none;

  &:focus {
    border-color: #4a90e2;
  }
`;

const BottomSection = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
  margin-top: 8px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const CalculationCard = styled.div`
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  padding: 20px;
`;

const CardTitle = styled.h3`
  font-size: 16px;
  font-weight: 600;
  color: #333333;
  margin: 0 0 10px 0;
`;

const CalculationRow = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 0;
  border-bottom: 1px solid #e0e0e0;

  &:last-child {
    border-bottom: none;
    padding-top: 16px;
    margin-top: 8px;
    border-top: 2px solid #e0e0e0;
  }
`;

const CalculationLabel = styled.span`
  font-size: 14px;
  color: #666666;
  font-weight: ${(props) => (props.bold ? "600" : "400")};
`;

const CalculationValue = styled.span`
  font-size: 14px;
  color: ${(props) => (props.highlight ? "#4a90e2" : "#333333")};
  font-weight: ${(props) => (props.bold ? "600" : "500")};
`;

const RiskFactorsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
  margin-top: 12px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const RiskFactorOption = styled.label`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 16px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s;
  background-color: ${(props) => (props.selected ? "#e3f2fd" : "#ffffff")};
  border-color: ${(props) => (props.selected ? "#1976d2" : "#e0e0e0")};

  &:hover {
    border-color: #1976d2;
  }
`;

const RiskFactorCheckbox = styled.input`
  width: 18px;
  height: 18px;
  cursor: pointer;
  accent-color: #4a90e2;
`;

const RiskFactorLabel = styled.span`
  font-size: 14px;
  color: #333333;
`;

const AadhaarScanButton = styled.button`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  background: linear-gradient(135deg, #4a90e2 0%, #357abd 100%);
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  box-shadow: 0 2px 4px rgba(74, 144, 226, 0.3);

  &:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(74, 144, 226, 0.4);
  }

  svg {
    width: 18px;
    height: 18px;
  }
`;

const AadhaarSection = styled.div`
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px;
  background-color: #f0f7ff;
  border: 1px dashed #4a90e2;
  border-radius: 8px;
  margin-bottom: 10px;
`;

const AadhaarInfo = styled.div`
  flex: 1;
`;

const AadhaarTitle = styled.h4`
  margin: 0 0 4px 0;
  font-size: 14px;
  font-weight: 600;
  color: #333;
`;

const AadhaarDescription = styled.p`
  margin: 0;
  font-size: 12px;
  color: #666;
`;

const ItemSearchWrapper = styled.div`
  position: relative;
  min-width: 180px;
`;

const SearchResults = styled.div`
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  background-color: #ffffff;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  max-height: 250px;
  overflow-y: auto;
  z-index: 9999;
  margin-top: 4px;
`;

const SearchResultItem = styled.div`
  padding: 10px 12px;
  cursor: pointer;
  font-size: 14px;
  color: #333333;
  border-bottom: 1px solid #f0f0f0;

  &:last-child {
    border-bottom: none;
  }

  &:hover {
    background-color: #f5f8ff;
  }
`;

const SearchResultEmpty = styled.div`
  padding: 12px;
  text-align: center;
  color: #666666;
  font-size: 14px;
`;

const DeleteItemButton = styled.button`
  background: none;
  border: none;
  padding: 4px;
  cursor: pointer;
  color: #e53935;
  display: flex;
  align-items: center;
  justify-content: center;

  &:hover {
    color: #c62828;
  }

  svg {
    width: 18px;
    height: 18px;
  }
`;
const FormRow = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;
const PageOverlay = styled.div`
  position: fixed;
  inset: 0;
  background: rgba(255, 255, 255, 0.6);
  backdrop-filter: blur(6px);
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
  pointer-events: all;
`;

const Spinner = styled.div`
  width: 48px;
  height: 48px;
  border: 4px solid #e0e0e0;
  border-top-color: #4a90e2;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;

  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }
`;
const AddDoctorButton = styled.button`
  margin-top: 28px;
  margin-right: 250px;
  background: none;
  color: #4a90e2;
  border: none;
  cursor: pointer;
  font-weight: 600;
  border-radius: 6px;
  border: 1px solid #4a90e2;

  &:hover {
    background-color: #4a90e2;
    color: #fff;
  }
`;

const ModalOverlay = styled.div`
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
`;

const ModalContent = styled.div`
  background: white;
  padding: 24px;
  border-radius: 8px;
  width: 400px;
`;

const ModalHeader = styled.h3`
  margin-bottom: 16px;
`;

const ModalActions = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 16px;
`;
const ErrorText = styled.span`
  display: block;
  margin-top: 6px;
  font-size: 12px;
  color: #e53935; /* soft red */
  font-weight: 500;

  /* subtle animation */
  opacity: 0;
  transform: translateY(-2px);
  animation: fadeIn 0.2s ease-in forwards;

  @keyframes fadeIn {
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
`;

const modalOverlayStyle = {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    background: "rgba(0,0,0,0.5)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 9999,
};

const modalStyle = {
    background: "#fff",
    padding: "24px",
    borderRadius: "8px",
    width: "400px",
    maxWidth: "90%",
};

const OPDPatientRegistration = () => {
    usePageTitle("OPD Patient Registration");
    const navigate = useNavigate();
    const location = useLocation();
    const resultRefs = useRef([]);
    const formRef = useRef(null);
    const [currentStep, setCurrentStep] = useState(1);
    const [isAadhaarScannerOpen, setIsAadhaarScannerOpen] = useState(false);
    const [pincodeError, setPincodeError] = useState("");
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isAddDoctorOpen, setIsAddDoctorOpen] = useState(false);
    const [availableDoctors, setAvailableDoctors] = useState([]);
    const [loadingDoctors, setLoadingDoctors] = useState(false);
    const [mobileError, setMobileError] = useState("");
    const [doctorFeeMap, setDoctorFeeMap] = useState({});
    const [activeResultIndex, setActiveResultIndex] = useState(-1);
    const [showConfirmModal, setShowConfirmModal] = useState(false);
    const [newDoctorData, setNewDoctorData] = useState({
        first_name: "",
        last_name: "",
        gender: "",
        practitioner_type: "External",
        custom_registration_number: "",
        custom_specializedqualification: "",
        status: "Active",
    });
    const [creatingDoctor, setCreatingDoctor] = useState(false);
    //search location
    const [addressSearch, setAddressSearch] = useState("");
    const [addressResults, setAddressResults] = useState([]);
    const [showAddressResults, setShowAddressResults] = useState(false);
    const [searchingAddress, setSearchingAddress] = useState(false);
    const [activeAddressIndex, setActiveAddressIndex] = useState(-1);
    const addressRefs = useRef([]);

    const mobileInputRef = useRef(null);
    const occupationInputRef = useRef(null);
    const getCurrentTimeHHMM = () => {
        const now = new Date();
        return now.toTimeString().slice(0, 5); // "14:30"
    };

    // Check if we're on pathlab route
    const isPathLabRoute = location.pathname.includes("/pathlab");
    const [formData, setFormData] = useState({
        firstName: "",
        middleName: "",
        lastName: "",
        uid: "",
        dateOfBirth: "",
        gender: "",
        mobile: "",
        company: "",
        bloodGroup: "",
        address_line1: "",
        address_line2: "",
        city: "",
        state: "",
        pincode: "",
        country: "",
        allergies: "",
        existingConditions: "",
        visitType: "walk-in",
        assignedDoctor: "",
        appointmentTime: getCurrentTimeHHMM(),
        appointmentDate: new Date().toISOString().split("T")[0],
    });

    const [medicalHistory, setMedicalHistory] = useState({
        occupation: "",
        maritalStatus: "",
        custom_religion: "",
        custom_cast: "",
        allergies: "",
        preExistingConditions: "",
        regularMedication: "",
        surgeryHistory: "",
        riskFactors: [],
        tobaccoPastUse: "",
        tobaccoCurrentUse: "",
        alcoholPastUse: "",
        alcoholCurrentUse: "",
        otherRiskFactors: "",
    });

    const [billingData, setBillingData] = useState({
        referringPractitioner: "",
        mode_of_payment: "Cash",
        editPostingDate: false,
        discountPercent: 0,
        reference_no: "",
        reference_date: "",
    });

    const [items, setItems] = useState(() => {
        if (isPathLabRoute) {
            return [];
        } else {
            return [{
                no: 1,
                item: "STO-ITEM-2025-00539",
                itemName: "",
                qty: 1,
                rate: 20,
                amount: 20,
            }];
        }
    });

    const [genderOptions, setGenderOptions] = useState([]);
    const [companyOptions, setCompanyOptions] = useState([]);
    const [practitioners, setPractitioners] = useState([]);
    const [disabledFields, setDisabledFields] = useState({});
    const [age, setAge] = useState(""); // UI-only field for age

    // Item search state
    const [itemSearchIndex, setItemSearchIndex] = useState(null);
    const [itemSearch, setItemSearch] = useState("");
    const [itemResults, setItemResults] = useState([]);
    const [showItemResults, setShowItemResults] = useState(false);
    const [searchingItem, setSearchingItem] = useState(false);
    const [isAadhaarOCRScannerOpen, setIsAadhaarOCRScannerOpen] = useState(false);
    const casteOptions = [
        { label: "General", value: "General" },
        { label: "SC", value: "SC" },
        { label: "ST", value: "ST" },
        { label: "OBC-A", value: "OBC-A" },
        { label: "OBC-B", value: "OBC-B" },
        { label: "Other", value: "Other" },
        { label: "Prefer Not to Say", value: "Prefer Not to Say" },
    ];
    const getFilteredCastes = () => {
        const religion = medicalHistory.custom_religion;

        if (!religion) return [];

        if (religion === "Hindu") {
            // All except OBC-B
            return casteOptions.filter(caste => caste.value !== "OBC-B");
        }

        if (religion === "Muslim") {
            // Only General and OBC-B
            return casteOptions.filter(caste =>
                caste.value === "General" || caste.value === "OBC-B"
            );
        }

        // For all other religions → return all but disabled
        return casteOptions;
    };

    // If address line 1 has a value, other address fields (except line 2) become required
    const hasAnyAddressValue = formData.address_line1?.trim().length > 0;

    useEffect(() => {
        if (formData.address_line1?.trim()) {
            // If address is entered, force country to India
            setFormData((prev) => ({
                ...prev,
                country: "India",
            }));
        } else {
            // If address is cleared, reset country (optional)
            setFormData((prev) => ({
                ...prev,
                country: "",
            }));
        }
    }, [formData.address_line1]);

    // Calculate age from date of birth
    const calculateAgeFromDOB = (dob) => {
        if (!dob) return "";
        const birthDate = new Date(dob);
        const today = new Date();
        let calculatedAge = today.getFullYear() - birthDate.getFullYear();
        const monthDiff = today.getMonth() - birthDate.getMonth();
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
            calculatedAge--;
        }
        return calculatedAge;
    };

    // Calculate DOB from age (set to 01/01/YYYY)
    const calculateDOBFromAge = (ageValue) => {
        if (!ageValue || isNaN(ageValue)) return "";
        const currentYear = new Date().getFullYear();
        const birthYear = currentYear - parseInt(ageValue);
        return `${birthYear}-01-01`;
    };

    // Helper function to match gender values
    const matchGenderValue = (genderValue, options) => {
        if (!genderValue) return "";

        const normalized = genderValue.trim().toLowerCase();
        console.log("Trying to match gender:", normalized);

        // Try exact match first
        const exactMatch = options.find(opt => opt.name.toLowerCase() === normalized);
        if (exactMatch) {
            console.log("Exact match found:", exactMatch.name);
            return exactMatch.name;
        }

        // Try matching common patterns
        const patterns = {
            'm': ['male', 'm'],
            'f': ['female', 'f'],
            't': ['transgender', 'trans', 't'],
            'o': ['other', 'o']
        };

        for (const [key, variations] of Object.entries(patterns)) {
            if (variations.some(v => normalized === v || normalized.startsWith(v))) {
                const match = options.find(opt => opt.name.toLowerCase().startsWith(key));
                if (match) {
                    console.log("Pattern match found:", match.name);
                    return match.name;
                }
            }
        }

        // Try partial match as fallback
        const partialMatch = options.find(opt => {
            const optName = opt.name.toLowerCase();
            return optName.startsWith(normalized) || normalized.startsWith(optName.charAt(0));
        });

        if (partialMatch) {
            console.log("Partial match found:", partialMatch.name);
            return partialMatch.name;
        }

        console.log("No match found, returning raw value");
        return genderValue;
    };

    // Normalize gender value when options are loaded (for auto-normalization after Aadhaar scan)
    useEffect(() => {
        if (genderOptions.length > 0 && formData.gender) {
            const currentValue = formData.gender.trim();

            // Check if current value is already a valid option
            const isValidOption = genderOptions.some(
                opt => opt.name.toLowerCase() === currentValue.toLowerCase()
            );

            if (!isValidOption) {
                // Try to match and normalize
                const matchedValue = matchGenderValue(currentValue, genderOptions);
                if (matchedValue && matchedValue !== currentValue) {
                    console.log("Auto-normalizing gender from", currentValue, "to", matchedValue);
                    setFormData((prev) => ({ ...prev, gender: matchedValue }));
                }
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [genderOptions]);

    // Auto-focus on appropriate field when step changes
    useEffect(() => {
        if (currentStep === 2 && occupationInputRef.current) {
            // Small delay to ensure the step content is rendered
            setTimeout(() => {
                occupationInputRef.current?.focus();
            }, 100);
        }
    }, [currentStep]);

    // Auto-select company if only one option is available
    useEffect(() => {
        if (companyOptions.length === 1 && !formData.company) {
            setFormData((prev) => ({ ...prev, company: companyOptions[0].name }));
        }
    }, [companyOptions, formData.company]);

    const fetchPractitioners = async () => {
        try {
            const practitionerRes = await apiService.get(
                API_ENDPOINTS.PRACTITIONERS.LIST,
                {
                    fields: '["name", "practitioner_name"]',
                    limit_page_length: 5000,
                }
            );

            if (practitionerRes.data?.data) {
                setPractitioners(practitionerRes.data.data);
            }
        } catch (error) {
            console.error("Error fetching practitioners:", error);
        }
    };

    // Fetch gender and company options from API
    useEffect(() => {
        const fetchGenderOptions = async () => {
            try {
                const response = await apiService.get("/resource/Gender");
                const data = await response.json();
                if (data && data.data) {
                    console.log("Gender options loaded:", data.data);
                    setGenderOptions(data.data);
                }
            } catch (error) {
                console.error("Error fetching gender options:", error);
            }
        };

        const fetchCompanyOptions = async () => {
            try {
                const response = await apiService.get("/resource/Company");
                const data = await response.json();
                if (data && data.data) {
                    setCompanyOptions(data.data);
                }
            } catch (error) {
                console.error("Error fetching company options:", error);
            }
        };

        fetchPractitioners();

        const fetchDefaultItem = async () => {
            try {
                const response = await apiService.get(API_ENDPOINTS.ITEMS.GET_BY_ID("STO-ITEM-2025-00539"));
                console.log("Default item fetched:", response.data);

                if (response.data && response.data.data) {
                    const itemData = response.data.data;
                    const defaultItem = {
                        no: 1,
                        item: itemData.name || itemData.item_code || "STO-ITEM-2025-00539",
                        itemName: itemData.item_name || "",
                        qty: 1,
                        rate: 20, // Fixed rate for default item
                        amount: 20,
                    };
                    setItems([defaultItem]);
                }
            } catch (error) {
                console.error("Error fetching default item:", error);
            }
        };

        fetchGenderOptions();
        fetchCompanyOptions();
        fetchPractitioners();

        // Fetch default item only for non-pathlab routes
        if (!isPathLabRoute) {
            fetchDefaultItem();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // Function to create a new doctor

    const handleInputChange = (e) => {
        const { name, value } = e.target;

        // Handle DOB change - calculate age
        if (name === "dateOfBirth") {
            setFormData((prev) => ({
                ...prev,
                [name]: value,
            }));
            setAge(calculateAgeFromDOB(value));
        } else {
            setFormData((prev) => ({
                ...prev,
                [name]: value,
            }));
        }
    };

    // Handle age input change - calculate DOB
    const handleAgeChange = (e) => {
        const ageValue = e.target.value;
        setAge(ageValue);

        if (ageValue && !isNaN(ageValue)) {
            const calculatedDOB = calculateDOBFromAge(ageValue);
            setFormData((prev) => ({
                ...prev,
                dateOfBirth: calculatedDOB,
            }));
        } else if (!ageValue) {
            // Clear DOB if age is cleared
            setFormData((prev) => ({
                ...prev,
                dateOfBirth: "",
            }));
        }
    };

    const handleAadhaarDataExtracted = (data) => {
        console.log("=== Aadhaar Scan Data ===");
        console.log("Extracted data:", data);
        console.log("Gender options available:", genderOptions.map(o => o.name));
        if (data.isDOBEstimated) {
            console.log("DOB estimated from year_of_birth");
        }
        // Match gender value with available options from API
        let matchedGender = "";
        if (data.gender) {
            if (genderOptions.length > 0) {
                matchedGender = matchGenderValue(data.gender, genderOptions);
                console.log("Final matched gender:", matchedGender);
            } else {
                // If options not loaded yet, store the raw value
                // It will be normalized when options load via useEffect
                matchedGender = data.gender.trim();
                console.log("Gender options not loaded yet, using raw value:", matchedGender);
            }
        }

        // Build distributed address fields from individual components
        const addressLine1Parts = [
            data.careOf ? `C/O ${data.careOf}` : "",
            data.house,
            data.street,
            data.landmark,
        ].filter((part) => part && part.trim());
        const addressLine1 = addressLine1Parts.join(", ");

        const addressLine2Parts = [
            data.location || data.locality,
            data.postOffice ? `PO: ${data.postOffice}` : "",
            data.vtc,
            data.subDistrict,
        ].filter((part) => part && part.trim());
        const addressLine2 = addressLine2Parts.join(", ");

        // Track which fields are being populated from Aadhaar
        const fieldsToDisable = {};
        if (data.firstName) fieldsToDisable.firstName = true;
        if (data.middleName) fieldsToDisable.middleName = true;
        if (data.lastName) fieldsToDisable.lastName = true;
        if (data.uid) fieldsToDisable.uid = true;
        if (data.dateOfBirth) fieldsToDisable.dateOfBirth = true;
        if (matchedGender) fieldsToDisable.gender = true;
        if (addressLine1 || data.address) fieldsToDisable.address_line1 = true;
        if (addressLine2) fieldsToDisable.address_line2 = true;
        if (data.district) fieldsToDisable.city = true;
        if (data.state) fieldsToDisable.state = true;
        if (data.pincode) fieldsToDisable.pincode = false;
        if (data.state) fieldsToDisable.country = true;

        setDisabledFields(fieldsToDisable);

        const newDOB = data.dateOfBirth || formData.dateOfBirth;
        setFormData((prev) => ({
            ...prev,
            firstName: data.firstName || prev.firstName,
            middleName: data.middleName || prev.middleName,
            lastName: data.lastName || prev.lastName,
            uid: data.uid || prev.uid,
            dateOfBirth: newDOB,
            gender: matchedGender || prev.gender,
            address_line1: addressLine1 || data.address || prev.address_line1,
            address_line2: addressLine2 || prev.address_line2,
            city: data.district || prev.city,
            state: data.state || prev.state,
            pincode: data.pincode || prev.pincode,
            country: data.state ? "India" : prev.country,
        }));

        // Calculate and set age if DOB is provided
        if (newDOB) {
            setAge(calculateAgeFromDOB(newDOB));
        }

        // Auto-focus on mobile number field after Aadhaar scan
        setTimeout(() => {
            if (mobileInputRef.current) {
                mobileInputRef.current.focus();
            }
        }, 100);
    };

    const handleBillingChange = (e) => {
        const { name, value, type, checked } = e.target;

        setBillingData((prev) => {
            // If payment type changes and it's NOT UPI → clear reference fields
            if (name === "mode_of_payment" && value !== "UPI") {
                return {
                    ...prev,
                    mode_of_payment: value,
                    reference_no: "",
                    reference_date: "",
                };
            }

            return {
                ...prev,
                [name]: type === "checkbox" ? (checked ? 1 : 0) : value,
            };
        });
    };

    const handleMedicalHistoryChange = (e) => {
        const { name, value } = e.target;

        setMedicalHistory(prev => ({
            ...prev,
            [name]: value,
            ...(name === "custom_religion" && { custom_cast: "" })
        }));
    };

    const toggleRiskFactor = (factor) => {
        setMedicalHistory((prev) => ({
            ...prev,
            riskFactors: prev.riskFactors.includes(factor) ? prev.riskFactors.filter((f) => f !== factor) : [...prev.riskFactors, factor],
        }));
    };

    // Debounced item search
    const searchItems = useCallback(async (query) => {
        if (!query || query.length < 2) {
            setItemResults([]);
            setShowItemResults(false);
            return;
        }

        setSearchingItem(true);

        try {
            const response = await apiService.get(API_ENDPOINTS.ITEMS.SEARCH, {
                doctype: "Item",
                txt: query.trim(),
                page_length: 10,
            });

            let results = response.data?.results || response.data?.message || [];

            // ✅ FILTER: Exclude LAB, PHC, PLB
            results = results.filter((item) => {
                const desc = item.description?.toUpperCase() || "";

                return !(
                    desc.startsWith("LAB") ||
                    desc.startsWith("PHC") ||
                    desc.startsWith("PLB")
                );
            });

            setItemResults(results);
            setShowItemResults(true);

        } catch (err) {
            console.error("Error searching items:", err);
        } finally {
            setSearchingItem(false);
        }
    }, []);

    // Debounce effect for item search
    useEffect(() => {
        const timer = setTimeout(() => {
            searchItems(itemSearch);
        }, 300);

        return () => clearTimeout(timer);
    }, [itemSearch, searchItems]);

    const handleItemSelect = async (item, index) => {
        try {
            // Fetch item details
            const itemCode = item.value || item.name;
            const response = await apiService.get(API_ENDPOINTS.ITEMS.GET_BY_ID(itemCode));
            const itemData = response.data?.data;

            // Fetch item price from Item Price API
            let rate = 0;
            try {
                const priceResponse = await apiService.get(API_ENDPOINTS.ITEMS.GET_PRICE, {
                    filters: JSON.stringify([["item_code", "=", itemCode], ["selling", "=", 1]]),
                    fields: JSON.stringify(["name", "item_code", "price_list", "price_list_rate", "currency", "uom", "valid_from", "valid_upto"]),
                });
                if (priceResponse.data?.data && priceResponse.data.data.length > 0) {
                    rate = priceResponse.data.data[0].price_list_rate || 0;
                }
            } catch (priceErr) {
                console.error("Error fetching item price:", priceErr);
                // Fallback to standard_rate if price fetch fails
                rate = itemData?.standard_rate || itemData?.valuation_rate || 0;
            }

            const updatedItems = [...items];
            const qty = updatedItems[index].qty || 1;

            updatedItems[index] = {
                ...updatedItems[index],
                no: index + 1,
                item: itemCode,
                itemName: itemData?.item_name || item.description || itemCode,
                qty: qty,
                rate: rate,
                amount: rate * qty,
            };
            setItems(updatedItems);
        } catch (err) {
            console.error("Error fetching item details:", err);
            const updatedItems = [...items];
            updatedItems[index] = {
                ...updatedItems[index],
                item: item.value || item.name,
                itemName: item.description || item.value || item.name,
            };
            setItems(updatedItems);
        }

        setItemSearch("");
        setShowItemResults(false);
        setItemSearchIndex(null);
    };

    const handleItemChange = (index, field, value) => {
        const updatedItems = [...items];
        updatedItems[index][field] = value;

        if (field === "qty" || field === "rate") {
            updatedItems[index].amount = updatedItems[index].qty * updatedItems[index].rate;
        }

        setItems(updatedItems);
    };

    const addItem = () => {
        const newItem = {
            item: "",
            itemName: "",
            qty: 1,
            rate: 0,
            amount: 0,
        };
        setItems([...items, newItem]);
    };

    // const removeItem = () => {
    //   if (items.length > 1) {
    //     setItems(items.slice(0, -1));
    //   }
    // };
    const removeItem = (index) => {
        if (items.length > 0) {
            const updatedItems = items.filter((_, i) => i !== index);
            setItems(updatedItems);
        }
    };

    //AutoFill Address
    const searchAddress = useCallback(async (query) => {
        if (!query || query.length < 3) {
            setAddressResults([]);
            setShowAddressResults(false);
            return;
        }

        setSearchingAddress(true);

        try {
            const res = await fetch(
                `https://midl.automedai.in/location/autocomplete?input=${encodeURIComponent(query)}`
            );

            const data = await res.json();

            if (data.success) {
                setAddressResults(data.data || []);
                setShowAddressResults(true);
            }
        } catch (err) {
            console.error("Address search error:", err);
        } finally {
            setSearchingAddress(false);
        }
    }, []);

    useEffect(() => {
        const timer = setTimeout(() => {
            searchAddress(addressSearch);
        }, 500);

        return () => clearTimeout(timer);
    }, [addressSearch, searchAddress]);

    useEffect(() => {
        if (
            activeAddressIndex >= 0 &&
            addressRefs.current[activeAddressIndex]
        ) {
            addressRefs.current[activeAddressIndex].scrollIntoView({
                block: "nearest",
            });
        }
    }, [activeAddressIndex]);

    const handleAddressSelect = async (place, index) => {
        try {
            const res = await fetch(
                `https://midl.automedai.in/location/details?place_id=${place.place_id}`
            );

            const data = await res.json();

            if (data.success && data.data) {
                const d = data.data;
                const addressLine1 = [d.sublocality, d.city]
                    .map(v => v?.trim())
                    .filter(v => v)
                    .join(", ");
                    
                setFormData((prev) => ({
                    ...prev,
                    address_line1: addressLine1,
                    address_line2: d.division || "",
                    city: d.district || "",
                    state: d.state || "",
                    country: d.country || "",
                    pincode: String(d.postal_code || ""),
                }));
            }
        } catch (err) {
            console.error("Error fetching address details:", err);
        }

        setShowAddressResults(false);
        setAddressSearch("");
        setActiveAddressIndex(-1);
    };

    const calculateTotals = () => {
        const totalQty = items.reduce((sum, item) => sum + parseFloat(item.qty || 0), 0);
        const grossTotal = items.reduce((sum, item) => sum + parseFloat(item.amount || 0), 0);
        const discountAmount = (grossTotal * parseFloat(billingData.discountPercent || 0)) / 100;
        const netTotal = grossTotal - discountAmount;

        return { totalQty, grossTotal, discountAmount, netTotal };
    };

    const handleNextStep = () => {
        if (currentStep < 2) {
            setCurrentStep(currentStep + 1);
        }
    };

    const handlePreviousStep = () => {
        if (currentStep > 1) {
            setCurrentStep(currentStep - 1);
        }
    };
    const fetchAvailableDoctors = async (company, date) => {
        if (!company || !date) {
            setAvailableDoctors([]);
            return;
        }

        try {
            setLoadingDoctors(true);

            const response = await fetch(
                `https://midl.automedai.in/doctor_room/assignments/by-company-date?company=${encodeURIComponent(company)}&schedule_date=${date}`
            );

            const data = await response.json();

            if (data.success) {
                setAvailableDoctors(data.data || []);
            } else {
                setAvailableDoctors([]);
            }
        } catch (error) {
            console.error("Error fetching available doctors:", error);
            setAvailableDoctors([]);
        } finally {
            setLoadingDoctors(false);
        }
    };

    useEffect(() => {
        const selectedDate =
            formData.appointmentDate || new Date().toISOString().split("T")[0];

        if (formData.company) {
            fetchAvailableDoctors(formData.company, selectedDate);
        }
    }, [formData.company, formData.appointmentDate]);

    const paidToMapping = {
        Cash: {
            "Ramakrishna Mission Sargachi": "Cash - RKMS",
            "ALFA DIAGNOSTIC CENTRE & POLYCLINIC": "Cash - ADC&P",
            "Automed AI": "Cash - AMAI",
        },
        UPI: {
            "Ramakrishna Mission Sargachi": "UPI-RKMS - RKMS",
            "ALFA DIAGNOSTIC CENTRE & POLYCLINIC": "UPI-ALFA - ADC&P",
            "Automed AI": "UPI-AAI - AMAI",
        }
    };

    const createPatient = async () => {
        setIsSubmitting(true);
        try {
            const payload = {
                doctype: "Patient",
                first_name: formData.firstName,
                middle_name: formData.middleName,
                last_name: formData.lastName,
                uid: formData.uid,
                Gender: formData.gender,
                sex: formData.gender,
                mobile: formData.mobile,
                dob: formData.dateOfBirth,
                custom_company: formData.company,
                blood_group: formData.bloodGroup,
                address_line1: formData.address_line1,
                address_line2: formData.address_line2,
                city: formData.city,
                state: formData.state,
                pincode: formData.pincode,
                country: formData.country,
                age: 0, // Ignoring as requested
                medical_history: formData.existingConditions,
                medication: medicalHistory.regularMedication,
                surgical_history: medicalHistory.surgeryHistory,
                surrounding_factors: "", // Keep blank as requested
                tobacco_past_use: medicalHistory.tobaccoPastUse,
                tobacco_current_use: medicalHistory.tobaccoCurrentUse,
                alcohol_past_use: medicalHistory.alcoholPastUse,
                alcohol_current_use: medicalHistory.alcoholCurrentUse,
                other_risk_factors: medicalHistory.otherRiskFactors,
                marital_status: medicalHistory.maritalStatus,
                custom_religion: medicalHistory.custom_religion,
                custom_cast: medicalHistory.custom_cast
            };

            // Add optional fields
            if (billingData.referringPractitioner) {
                payload.default_practitioner = billingData.referringPractitioner;
            }

            console.log("Creating patient with payload:", payload);

            const response = await apiService.post("/resource/Patient", {
                body: JSON.stringify(payload),
            });

            const data = await response.json();

            if (response.ok) {
                console.log("Patient created successfully:", data);

                // Get patient details from response
                const patientId = data.data?.name;
                const customer = data.data?.customer;
                let appointmentId = null;

                // ----------------------------
                // CREATE PATIENT APPOINTMENT
                // ----------------------------
                if (requiresAppointment) {
                    try {
                        const appointmentPayload = {
                            appointment_for: "Practitioner",
                            appointment_based_on_check_in: 1,
                            company: formData.company,
                            appointment_type: "Doctor Consultation",
                            practitioner: billingData.referringPractitioner,
                            patient: patientId,
                            appointment_date: formData.appointmentDate,
                            appointment_time: formData.appointmentTime,
                            duration: "0",
                            status: "Confirmed",
                        };

                        console.log("Creating appointment:", appointmentPayload);

                        const appointmentResponse = await apiService.post(
                            "/resource/Patient Appointment",
                            {
                                body: JSON.stringify(appointmentPayload),
                            }
                        );

                        const appointmentData = await appointmentResponse.json();
                        if (appointmentResponse.ok) {
                            console.log("Appointment created successfully:", appointmentData);
                            appointmentId = appointmentData.data?.name;
                        } else {
                            console.error("Appointment creation failed:", appointmentData);
                            alert(
                                `Patient created, but appointment failed: ${appointmentData.message || "Unknown error"
                                }`
                            );
                        }
                    } catch (appointmentError) {
                        console.error("Error creating appointment:", appointmentError);
                        alert("Patient created, but appointment could not be created.");
                    }
                }
                // ----------------------------
                // CREATE QUEUE NUMBER
                // ----------------------------
                if (requiresAppointment && appointmentId && billingData.referringPractitioner) {
                    try {
                        const queuePayload = {
                            appointment_id: appointmentId,
                            doctor_id: billingData.referringPractitioner,
                            company: formData.company,
                            patient_id: patientId,
                            appointment_date: formData.appointmentDate,
                        };

                        console.log("Creating queue no:", queuePayload);

                        const queueResponse = await fetch(
                            "https://midl.automedai.in/appointments/create",
                            {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json",
                                    Accept: "application/json",
                                },
                                body: JSON.stringify(queuePayload),
                            }
                        );

                        const queueData = await queueResponse.json();

                        if (queueResponse.ok) {
                            console.log("Queue no created successfully:", queueData);
                        } else {
                            console.error("Queue creation failed:", queueData);
                            alert(
                                `Patient & appointment created, but queue failed: ${queueData.message || "Unknown error"
                                }`
                            );
                        }
                    } catch (queueError) {
                        console.error("Error creating queue:", queueError);
                        alert("Patient & appointment created, but queue could not be created.");
                    }
                }

                const patientName = data.data?.patient_name || `${formData.firstName} ${formData.middleName} ${formData.lastName}`.trim();
                const company = formData.company;
                // Create Sales Invoice if there are billing items
                if (items.length > 0 && items.some(item => item.item)) {
                    try {
                        console.log("Creating Sales Invoice...");

                        // Map items to Sales Invoice format
                        const invoiceItems = items
                            .filter(item => item.item) // Only include items with item_code
                            .map(item => ({
                                item_code: item.item,
                                // item_name: item.itemName || item.item,
                                // description: item.itemName || item.item,
                                // warehouse: "Finished Goods - RKMS",
                                // income_account: "Sales - RKMS",
                                // expense_account: "Cost of Goods Sold - RKMS",
                                // cost_center: "Main - RKMS",
                                uom: "Unit",
                                qty: parseFloat(item.qty) || 1,
                                rate: parseFloat(item.rate) || 0,
                            }));

                        // Prepare Sales Invoice payload
                        const invoicePayload = {
                            docstatus: 1,
                            doctype: "Sales Invoice",
                            naming_series: "SINV-.YY.-",
                            company: company,
                            posting_date: new Date().toISOString().split("T")[0],
                            set_posting_time: 1,
                            is_pos: 0,
                            customer: customer,
                            patient: patientId,
                            patient_name: patientName,
                            currency: "INR",
                            selling_price_list: "Standard Selling",
                            update_stock: 0,
                            items: invoiceItems,
                            apply_discount_on: "Grand Total",
                            additional_discount_percentage: parseFloat(billingData.discountPercent) || 0,
                            rounding_adjustment: 0,
                            mode_of_transport: "Road",
                            gst_vehicle_type: "Regular",
                            // service_unit: "All Healthcare Service Units - RKMS",
                        };

                        // Add ref_practitioner if selected
                        if (billingData.referringPractitioner) {
                            invoicePayload.ref_practitioner = billingData.referringPractitioner;
                        }

                        console.log("Sales Invoice payload:", invoicePayload);

                        const invoiceResponse = await apiService.post("/resource/Sales%20Invoice", {
                            body: JSON.stringify(invoicePayload),
                        });

                        const invoiceData = await invoiceResponse.json();

                        if (invoiceResponse.ok) {
                            console.log("Sales Invoice created successfully:", invoiceData);

                            // Get invoice name and totals
                            const invoiceName = invoiceData.data?.name;
                            const totals = calculateTotals();
                            const netTotal = totals.netTotal;
                            const paidToAccount =
                                paidToMapping[billingData.mode_of_payment]?.[formData.company] || "";
                            // Create Payment Entry
                            if (netTotal > 0) {
                                try {
                                    console.log("Creating Payment Entry...");

                                    const paymentPayload = {
                                        doctype: "Payment Entry",
                                        docstatus: 1,
                                        payment_type: "Receive",
                                        posting_date: new Date().toISOString().split("T")[0],
                                        company: company,
                                        mode_of_payment: billingData.mode_of_payment,
                                        party_type: "Customer",
                                        party: customer,
                                        paid_amount: netTotal,
                                        received_amount: netTotal,
                                        target_exchange_rate: 1,
                                        reference_no: billingData.reference_no,
                                        reference_date: billingData.reference_date,
                                        paid_to: paidToAccount,
                                        paid_to_account_currency: "INR",
                                        references: [
                                            {
                                                reference_doctype: "Sales Invoice",
                                                reference_name: invoiceName,
                                                total_amount: netTotal,
                                                outstanding_amount: netTotal,
                                                allocated_amount: netTotal,
                                            }
                                        ]
                                    };

                                    const paymentResponse = await apiService.post("/resource/Payment%20Entry", {
                                        body: JSON.stringify(paymentPayload),
                                    });

                                    const paymentData = await paymentResponse.json();

                                    if (paymentResponse.ok) {
                                        console.log("Payment Entry created successfully:", paymentData);
                                        alert("Patient registered, invoice created, and payment recorded successfully!");
                                    } else {
                                        console.error("Error creating Payment Entry:", paymentData);
                                        alert(`Patient and invoice created, but payment failed: ${paymentData.message || "Unknown error"}`);
                                    }
                                } catch (paymentError) {
                                    console.error("Error creating Payment Entry:", paymentError);
                                    alert("Patient and invoice created, but payment failed. Please record manually.");
                                }
                            } else {
                                console.log("Skipping Payment Entry: netTotal is 0");

                                alert("Patient registered and invoice created successfully (no payment needed).");
                            }
                        } else {
                            console.error("Error creating Sales Invoice:", invoiceData);
                            alert(`Patient registered but invoice creation failed: ${invoiceData.message || "Unknown error"}`);
                        }
                    } catch (invoiceError) {
                        console.error("Error creating Sales Invoice:", invoiceError);
                        alert("Patient registered but invoice creation failed. Please create invoice manually.");
                    }
                } else {
                    alert("Patient registered successfully!");
                }

                navigate(`/prescription/${patientId}`, {
                    state: {
                        autoPrint: true
                    }
                });
            } else {
                console.error("Error creating patient:", data);
                alert(`Error creating patient: ${data.message || "Unknown error"}`);
            }
        } catch (error) {
            console.error("Error creating patient:", error);
            alert("Error creating patient. Please try again.");
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (currentStep < 2) {
            handleNextStep();
        } else {
            if (requiresAppointment) {
                if (!formData.appointmentDate || !formData.appointmentTime) {
                    alert("Please select Appointment Date and Time.");
                    return;
                }
            }
            // Final submission (Step 3 is now the last step)
            console.log("Form data:", formData);
            console.log("Medical History:", medicalHistory);
            console.log("Billing data:", billingData);
            // console.log("Appointment data", appointmentData);
            console.log("Items:", items);
            console.log("Final submission");
            createPatient();
        }
    };

    // const handleConfirmSubmit = () => {
    //     setShowConfirmModal(false);
    //     handleSubmit();
    // };
    const handleConfirmSubmit = () => {
        setShowConfirmModal(false);

        if (formRef.current) {
            formRef.current.requestSubmit(); // ✅ triggers real form submit
        }
    };

    const handleCancelSubmit = () => {
        setShowConfirmModal(false);
    };

    useEffect(() => {
        const handleKeyDown = (e) => {
            if (showConfirmModal && e.key === "Enter") {
                handleConfirmSubmit();
            }
        };

        window.addEventListener("keydown", handleKeyDown);
        return () => window.removeEventListener("keydown", handleKeyDown);
    }, [showConfirmModal]);

    const requiresAppointment = items.some(
        (item) => item.item === "STO-ITEM-2025-00539"
    );

    const maskAadhaar = (uid) => {
        if (!uid) return "";
        const last4 = uid.slice(-4);
        return `********${last4}`;
    };

    const getCurrentISTTime = () => {
        const now = new Date();

        // Convert to IST manually
        const istOffset = 5.5 * 60; // minutes
        const utc = now.getTime() + now.getTimezoneOffset() * 60000;
        const istTime = new Date(utc + istOffset * 60000);

        return istTime;
    };

    const filteredDoctors = availableDoctors.filter((doc) => {
        if (!doc.to_time) return false;

        if (!formData.appointmentDate) return true;

        const getTodayIST = () => {
            const now = new Date();
            const istOffset = 5.5 * 60;
            const utc = now.getTime() + now.getTimezoneOffset() * 60000;
            return new Date(utc + istOffset * 60000)
                .toISOString()
                .split("T")[0];
        };

        const today = getTodayIST();

        if (formData.appointmentDate !== today) return true;

        const nowIST = getCurrentISTTime();

        const [hours, minutes] = doc.to_time.split(":");
        const doctorEndTime = new Date(nowIST);

        doctorEndTime.setHours(parseInt(hours));
        doctorEndTime.setMinutes(parseInt(minutes));
        doctorEndTime.setSeconds(0);

        return nowIST <= doctorEndTime;
    });

    const fetchDoctorFee = async (company, doctorId) => {
        try {
            const res = await fetch(
                `https://midl.automedai.in/doctor_company/empanel/company/${encodeURIComponent(company)}/doctor/${doctorId}`
            );

            const data = await res.json();

            if (data.success && data.data?.consultation_fee) {
                const fee = data.data.consultation_fee;

                setDoctorFeeMap((prev) => ({
                    ...prev,
                    [doctorId]: fee,
                }));

                return fee;
            }

            return null;
        } catch (error) {
            console.error("Error fetching fee:", error);
            return null;
        }
    };

    useEffect(() => {
        const applyDoctorFee = async () => {
            const doctorId = billingData.referringPractitioner;
            const company = formData.company;

            if (!doctorId || !company) return;
            if (items.length === 0) return;

            // Check if consultation item exists
            const hasConsultationItem = items.some(
                (item) => item.item === "STO-ITEM-2025-00539"
            );

            if (!hasConsultationItem) return;

            // Fetch fee
            const fee = await fetchDoctorFee(company, doctorId);

            if (!fee) return;

            // Apply fee ONLY to consultation item
            setItems((prevItems) =>
                prevItems.map((item) => {
                    if (item.item === "STO-ITEM-2025-00539") {
                        const qty = parseFloat(item.qty) || 1;

                        return {
                            ...item,
                            rate: fee,
                            amount: fee * qty,
                        };
                    }
                    return item;
                })
            );
        };

        applyDoctorFee();
    }, [billingData.referringPractitioner, formData.company]);

    useEffect(() => {
        if (activeResultIndex >= 0 && resultRefs.current[activeResultIndex]) {
            resultRefs.current[activeResultIndex].scrollIntoView({
                block: "nearest",
                behavior: "smooth", // optional (remove if you want instant)
            });
        }
    }, [activeResultIndex]);

    useEffect(() => {
        resultRefs.current = [];
    }, [itemResults]);

    const doctorOptions = requiresAppointment
        ? filteredDoctors.map((doc) => ({
            label: `${doc.doctor_name} (${doc.room_name}) ${doc.from_time.slice(0, 5)} - ${doc.to_time.slice(0, 5)}`,
            value: doc.doctor_id,
        }))
        : practitioners.map((doc) => ({
            label: doc.practitioner_name,
            value: doc.name,
        }));

    useEffect(() => {
        setBillingData((prev) => ({
            ...prev,
            referringPractitioner: "",
        }));
    }, [requiresAppointment]);

    return (
        <Layout>
            {isSubmitting && (
                <PageOverlay>
                    <Spinner />
                </PageOverlay>
            )}
            <RegistrationContainer>
                <ProgressIndicator>
                    <ProgressStepsContainer>
                        <ProgressStep>
                            <StepLabel active={currentStep >= 1}>Step 1: Registration</StepLabel>
                        </ProgressStep>
                        {/* <ProgressStep>
                            <StepLabel active={currentStep >= 2}>Step 2: Medical History</StepLabel>
                        </ProgressStep> */}
                        <ProgressStep>
                            <StepLabel active={currentStep >= 2}>Step 2: Billing</StepLabel>
                        </ProgressStep>
                        {/* <ProgressStep>
              <StepLabel active={currentStep >= 4}>Step 4: Pre-Screening</StepLabel>
            </ProgressStep> */}
                    </ProgressStepsContainer>
                    <ProgressBarContainer>
                        <ProgressBarFill currentStep={currentStep} />
                    </ProgressBarContainer>
                </ProgressIndicator>

                <form ref={formRef} onSubmit={handleSubmit}>
                    {currentStep === 1 && (
                        <>
                            <AadhaarSection>
                                <CreditCard size={32} color="#4a90e2" />
                                <AadhaarInfo>
                                    <AadhaarTitle>Quick Registration with Aadhaar</AadhaarTitle>
                                    <AadhaarDescription>
                                        Scan Aadhaar QR code or upload Aadhaar card image to auto-fill patient details
                                    </AadhaarDescription>
                                </AadhaarInfo>
                                {/* <AadhaarScanButton type="button" onClick={() => setIsAadhaarScannerOpen(true)}>
                                    <Camera />
                                    Scan Aadhaar
                                </AadhaarScanButton> */}
                                <AadhaarScanButton
                                    type="button"
                                    onClick={() => setIsAadhaarOCRScannerOpen(true)}
                                >
                                    <Camera />
                                    Scan Aadhaar
                                </AadhaarScanButton>
                            </AadhaarSection>

                            <FormSection>
                                {/* <SectionTitle>Personal Information</SectionTitle> */}
                                <FormGrid>
                                    <FormGroup>
                                        <FormLabel>First Name<RequiredAsterisk>*</RequiredAsterisk></FormLabel>
                                        <FormInput
                                            type="text"
                                            name="firstName"
                                            value={formData.firstName}
                                            onChange={handleInputChange}
                                            onInput={(e) => {
                                                e.target.value = e.target.value.replace(/[^a-zA-Z\s]/g, "");
                                                handleInputChange(e);
                                            }}
                                            pattern="[a-zA-Z\s]+"
                                            placeholder="Enter first name"
                                            required
                                            disabled={disabledFields.firstName}
                                            autoFocus
                                        />
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>Middle Name (Optional)</FormLabel>
                                        <FormInput
                                            type="text"
                                            name="middleName"
                                            value={formData.middleName}
                                            onChange={handleInputChange}
                                            onInput={(e) => {
                                                e.target.value = e.target.value.replace(/[^a-zA-Z\s]/g, "");
                                                handleInputChange(e);
                                            }}
                                            pattern="[a-zA-Z\s]*"
                                            placeholder="Enter middle name"
                                            disabled={disabledFields.middleName}
                                        />
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>Last Name<RequiredAsterisk>*</RequiredAsterisk></FormLabel>
                                        <FormInput
                                            type="text"
                                            name="lastName"
                                            value={formData.lastName}
                                            onChange={handleInputChange}
                                            onInput={(e) => {
                                                e.target.value = e.target.value.replace(/[^a-zA-Z\s]/g, "");
                                                handleInputChange(e);
                                            }}
                                            pattern="[a-zA-Z\s]+"
                                            placeholder="Enter last name"
                                            required
                                            disabled={disabledFields.lastName}
                                        />
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>Identification Number (UID)</FormLabel>
                                        <FormInput type="text" name="uid" value={maskAadhaar(formData.uid)} onChange={handleInputChange} disabled />
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>Date of Birth</FormLabel>
                                        <FormInput
                                            type="date"
                                            name="dateOfBirth"
                                            value={formData.dateOfBirth}
                                            onChange={handleInputChange}
                                            max={new Date().toISOString().split("T")[0]}
                                            disabled={disabledFields.dateOfBirth}
                                        />
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>Age (Years)</FormLabel>
                                        <FormInput
                                            type="number"
                                            name="age"
                                            value={age}
                                            onChange={handleAgeChange}
                                            placeholder="Enter age"
                                            min="0"
                                            max="150"
                                        />
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>
                                            Gender<RequiredAsterisk>*</RequiredAsterisk>
                                        </FormLabel>

                                        <Select
                                            options={genderOptions.map((option) => ({
                                                label: option.name,
                                                value: option.name,
                                            }))}

                                            value={
                                                genderOptions
                                                    .map((option) => ({
                                                        label: option.name,
                                                        value: option.name,
                                                    }))
                                                    .find((opt) => opt.value === formData.gender) || null
                                            }

                                            onChange={(selected) =>
                                                setFormData((prev) => ({
                                                    ...prev,
                                                    gender: selected ? selected.value : "",
                                                }))
                                            }

                                            placeholder="Select Gender"
                                            isSearchable
                                            isClearable
                                            required
                                        />
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>Mobile</FormLabel>
                                        <FormInput
                                            ref={mobileInputRef}
                                            type="tel"
                                            name="mobile"
                                            value={formData.mobile}
                                            onChange={handleInputChange}
                                            onInput={(e) => {
                                                const cleaned = e.target.value.replace(/[^0-9]/g, "").slice(0, 10);
                                                e.target.value = cleaned;

                                                // 🔥 Real-time validation
                                                if (cleaned.length > 0) {
                                                    if (!/^[6-9]/.test(cleaned)) {
                                                        setMobileError("Mobile Number must start with 6, 7, 8, or 9");
                                                    } else if (cleaned.length === 10 && !/^[6-9]\d{9}$/.test(cleaned)) {
                                                        setMobileError("Invalid mobile number");
                                                    } else {
                                                        setMobileError("");
                                                    }
                                                } else {
                                                    setMobileError("");
                                                }

                                                handleInputChange(e);
                                            }}
                                            maxLength={10}
                                            pattern="[6-9]{1}[0-9]{9}"
                                            placeholder="Enter 10-digit mobile number"
                                        />
                                        {mobileError && <ErrorText>{mobileError}</ErrorText>}
                                        <HelperText>Existing patient data will be fetched automatically.</HelperText>
                                    </FormGroup>
                                    <FormGroup style={{ display: "none" }}>
                                        <FormLabel>
                                            Clinic<RequiredAsterisk>*</RequiredAsterisk>
                                        </FormLabel>

                                        <Select
                                            options={companyOptions.map((option) => ({
                                                label: option.name,
                                                value: option.name,
                                            }))}

                                            value={
                                                companyOptions
                                                    .map((option) => ({
                                                        label: option.name,
                                                        value: option.name,
                                                    }))
                                                    .find((opt) => opt.value === formData.company) || null
                                            }

                                            onChange={(selected) =>
                                                setFormData((prev) => ({
                                                    ...prev,
                                                    company: selected ? selected.value : "",
                                                }))
                                            }

                                            placeholder="Search clinic..."
                                            isSearchable
                                            isClearable
                                        />
                                    </FormGroup>

                                    <FormGroup style={{ display: "none" }}>
                                        <FormLabel>Blood Group</FormLabel>
                                        <FormSelect name="bloodGroup" value={formData.bloodGroup} onChange={handleInputChange}>
                                            <option value="">Select blood group</option>
                                            <option value="A Positive">A Positive</option>
                                            <option value="A Negative">A Negative</option>
                                            <option value="B Positive">B Positive</option>
                                            <option value="B Negative">B Negative</option>
                                            <option value="AB Positive">AB Positive</option>
                                            <option value="AB Negative">AB Negative</option>
                                            <option value="O Positive">O Positive</option>
                                            <option value="O Negative">O Negative</option>
                                        </FormSelect>
                                    </FormGroup>

                                    {/* <FormGroup>
                                        <FormLabel>Address Line 1{hasAnyAddressValue && <RequiredAsterisk>*</RequiredAsterisk>}</FormLabel>
                                        <FormInput
                                            type="text"
                                            name="address_line1"
                                            value={formData.address_line1}
                                            onChange={handleInputChange}
                                            placeholder="Enter address line 1"
                                            disabled={disabledFields.address_line1}
                                            required={hasAnyAddressValue}
                                        />
                                    </FormGroup> */}
                                    <FormGroup>
                                        <FormLabel>
                                            Address Line 1{hasAnyAddressValue && <RequiredAsterisk>*</RequiredAsterisk>}
                                        </FormLabel>

                                        <div style={{ position: "relative", display: "block", width: "100%" }}>
                                            <FormInput
                                                style={{ width: "100%" }}
                                                type="text"
                                                name="address_line1"
                                                value={formData.address_line1}
                                                onChange={(e) => {
                                                    handleInputChange(e);
                                                    setAddressSearch(e.target.value);
                                                    setActiveAddressIndex(-1);
                                                }}
                                                onKeyDown={(e) => {
                                                    if (!showAddressResults) return;

                                                    if (e.key === "ArrowDown") {
                                                        e.preventDefault();
                                                        setActiveAddressIndex((prev) =>
                                                            prev < addressResults.length - 1 ? prev + 1 : 0
                                                        );
                                                    }

                                                    if (e.key === "ArrowUp") {
                                                        e.preventDefault();
                                                        setActiveAddressIndex((prev) =>
                                                            prev > 0 ? prev - 1 : addressResults.length - 1
                                                        );
                                                    }

                                                    if (e.key === "Enter") {
                                                        e.preventDefault();
                                                        if (activeAddressIndex >= 0) {
                                                            handleAddressSelect(addressResults[activeAddressIndex]);
                                                        }
                                                    }
                                                }}
                                                onFocus={() => {
                                                    if (addressSearch.length >= 3) {
                                                        setShowAddressResults(true);
                                                    }
                                                }}
                                                onBlur={() => setTimeout(() => setShowAddressResults(false), 200)}
                                                placeholder="Start typing address..."
                                                disabled={disabledFields.address_line1}
                                                required={hasAnyAddressValue}
                                            />

                                            {/* DROPDOWN */}
                                            {showAddressResults && (
                                                <div
                                                    style={{
                                                        position: "absolute",
                                                        top: "100%",
                                                        left: 0,
                                                        right: 0,
                                                        background: "#fff",
                                                        border: "1px solid #ddd",
                                                        borderRadius: "6px",
                                                        maxHeight: "200px",
                                                        overflowY: "auto",
                                                        zIndex: 1000,
                                                    }}
                                                >
                                                    {addressResults.length > 0 ? (
                                                        addressResults.map((item, idx) => (
                                                            <div
                                                                key={idx}
                                                                ref={(el) => (addressRefs.current[idx] = el)}
                                                                onMouseDown={() => handleAddressSelect(item)}
                                                                style={{
                                                                    padding: "10px",
                                                                    cursor: "pointer",
                                                                    background:
                                                                        activeAddressIndex === idx ? "#eee" : "#fff",
                                                                }}
                                                            >
                                                                {item.description}
                                                            </div>
                                                        ))
                                                    ) : (
                                                        <div style={{ padding: "10px" }}>
                                                            {searchingAddress ? "Searching..." : "No results"}
                                                        </div>
                                                    )}
                                                </div>
                                            )}
                                        </div>
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>Address Line 2</FormLabel>
                                        <FormInput
                                            type="text"
                                            name="address_line2"
                                            value={formData.address_line2}
                                            onChange={handleInputChange}
                                            placeholder="Enter address line 2"
                                            disabled={disabledFields.address_line2}
                                        />
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>District{hasAnyAddressValue && <RequiredAsterisk>*</RequiredAsterisk>}</FormLabel>
                                        <FormInput
                                            type="text"
                                            name="city"
                                            value={formData.city}
                                            onChange={handleInputChange}
                                            placeholder="Enter district"
                                            required={hasAnyAddressValue}
                                            disabled={disabledFields.city}
                                        />
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>State{hasAnyAddressValue && <RequiredAsterisk>*</RequiredAsterisk>}</FormLabel>
                                        <FormSelect name="state" value={formData.state} onChange={handleInputChange} required={hasAnyAddressValue} disabled={disabledFields.state}>
                                            <option value="">Select state</option>
                                            <option value="Andhra Pradesh">Andhra Pradesh</option>
                                            <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                            <option value="Assam">Assam</option>
                                            <option value="Bihar">Bihar</option>
                                            <option value="Chhattisgarh">Chhattisgarh</option>
                                            <option value="Goa">Goa</option>
                                            <option value="Gujarat">Gujarat</option>
                                            <option value="Haryana">Haryana</option>
                                            <option value="Himachal Pradesh">Himachal Pradesh</option>
                                            <option value="Jharkhand">Jharkhand</option>
                                            <option value="Karnataka">Karnataka</option>
                                            <option value="Kerala">Kerala</option>
                                            <option value="Madhya Pradesh">Madhya Pradesh</option>
                                            <option value="Maharashtra">Maharashtra</option>
                                            <option value="Manipur">Manipur</option>
                                            <option value="Meghalaya">Meghalaya</option>
                                            <option value="Mizoram">Mizoram</option>
                                            <option value="Nagaland">Nagaland</option>
                                            <option value="Odisha">Odisha</option>
                                            <option value="Punjab">Punjab</option>
                                            <option value="Rajasthan">Rajasthan</option>
                                            <option value="Sikkim">Sikkim</option>
                                            <option value="Tamil Nadu">Tamil Nadu</option>
                                            <option value="Telangana">Telangana</option>
                                            <option value="Tripura">Tripura</option>
                                            <option value="Uttar Pradesh">Uttar Pradesh</option>
                                            <option value="Uttarakhand">Uttarakhand</option>
                                            <option value="West Bengal">West Bengal</option>
                                            <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                                            <option value="Chandigarh">Chandigarh</option>
                                            <option value="Dadra and Nagar Haveli and Daman and Diu">Dadra and Nagar Haveli and Daman and Diu</option>
                                            <option value="Delhi">Delhi</option>
                                            <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                                            <option value="Ladakh">Ladakh</option>
                                            <option value="Lakshadweep">Lakshadweep</option>
                                            <option value="Puducherry">Puducherry</option>
                                        </FormSelect>
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>Pincode{hasAnyAddressValue && <RequiredAsterisk>*</RequiredAsterisk>}</FormLabel>
                                        <FormInput
                                            type="text"
                                            name="pincode"
                                            value={formData.pincode}
                                            onChange={handleInputChange}
                                            onInput={(e) => {
                                                const cleaned = e.target.value.replace(/[^0-9]/g, "").slice(0, 6);
                                                e.target.value = cleaned;

                                                // 🔥 Real-time validation
                                                if (cleaned.length > 0) {
                                                    if (!/^[1-9]/.test(cleaned)) {
                                                        setPincodeError("Pincode cannot start with 0");
                                                    } else if (cleaned.length === 6 && !/^[1-9][0-9]{5}$/.test(cleaned)) {
                                                        setPincodeError("Invalid pincode");
                                                    } else {
                                                        setPincodeError("");
                                                    }
                                                } else {
                                                    setPincodeError("");
                                                }

                                                handleInputChange(e);
                                            }}
                                            maxLength={6}
                                            pattern="[1-9][0-9]{5}"
                                            placeholder="Enter 6-digit pincode"
                                            required={hasAnyAddressValue}
                                            disabled={disabledFields.pincode}
                                        />
                                        {pincodeError && <ErrorText>{pincodeError}</ErrorText>}
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>Country{hasAnyAddressValue && <RequiredAsterisk>*</RequiredAsterisk>}</FormLabel>
                                        <FormInput
                                            type="text"
                                            name="country"
                                            value={formData.country}
                                            onChange={handleInputChange}
                                            placeholder="Enter country"
                                            required={hasAnyAddressValue}
                                            disabled={disabledFields.country}
                                        />
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>Religion</FormLabel>
                                        <FormSelect
                                            name="custom_religion"
                                            value={medicalHistory.custom_religion}
                                            onChange={handleMedicalHistoryChange}
                                        >
                                            <option value="">Select Religion</option>
                                            <option value="Hindu">Hindu</option>
                                            <option value="Muslim">Muslim</option>
                                            <option value="Christian">Christian</option>
                                            <option value="Sikh">Sikh</option>
                                            <option value="Buddhist">Buddhist</option>
                                            <option value="Jain">Jain</option>
                                            <option value="Parsi">Parsi</option>
                                            <option value="Jewish">Jewish</option>
                                            <option value="Atheist / No Religion">Atheist / No Religion</option>
                                            <option value="Other">Other</option>
                                        </FormSelect>
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>Caste</FormLabel>
                                        <FormSelect
                                            name="custom_cast"
                                            value={medicalHistory.custom_cast}
                                            onChange={handleMedicalHistoryChange}
                                            disabled={
                                                medicalHistory.custom_religion !== "Hindu" &&
                                                medicalHistory.custom_religion !== "Muslim"
                                            }
                                        >
                                            <option value="">Select Caste</option>

                                            {getFilteredCastes().map((caste) => (
                                                <option key={caste.value} value={caste.value}>
                                                    {caste.label}
                                                </option>
                                            ))}
                                        </FormSelect>
                                    </FormGroup>
                                </FormGrid>
                            </FormSection>
                        </>
                    )}

                    {/* {currentStep === 2 && (
                        <>
                            <FormSection>
                                <SectionTitle>Personal & Social History</SectionTitle>
                                <FormGrid>
                                    <FormGroup>
                                        <FormLabel>Religion</FormLabel>
                                        <FormSelect name="custom_religion" value={medicalHistory.custom_religion} onChange={handleMedicalHistoryChange}>
                                            <option value="">Select Religion</option>
                                            <option value="Hindu">Hindu</option>
                                            <option value="Muslim">Muslim</option>
                                            <option value="Christian">Christian</option>
                                            <option value="Sikh">Sikh</option>
                                            <option value="Buddhist">Buddhist</option>
                                            <option value="Jain">Jain</option>
                                            <option value="Parsi">Parsi</option>
                                            <option value="Jewish">Jewish</option>
                                            <option value="Atheist / No Religion">Atheist / No Religion</option>
                                            <option value="Other">Other</option>
                                        </FormSelect>
                                    </FormGroup>

                                    {medicalHistory.custom_religion === "Hindu" ||
                                        medicalHistory.custom_religion === "Muslim" ||
                                        medicalHistory.custom_religion ? (

                                        <FormGroup>
                                            <FormLabel>Caste</FormLabel>
                                            <FormSelect
                                                name="custom_cast"
                                                value={medicalHistory.custom_cast}
                                                onChange={handleMedicalHistoryChange}
                                                disabled={
                                                    medicalHistory.custom_religion !== "Hindu" &&
                                                    medicalHistory.custom_religion !== "Muslim"
                                                }
                                            >
                                                <option value="">Select Caste</option>

                                                {getFilteredCastes().map((caste) => (
                                                    <option key={caste.value} value={caste.value}>
                                                        {caste.label}
                                                    </option>
                                                ))}
                                            </FormSelect>
                                        </FormGroup>

                                    ) : null}

                                    <FormGroup>
                                        <FormLabel>Occupation</FormLabel>
                                        <FormInput ref={occupationInputRef} type="text" name="occupation" value={medicalHistory.occupation} onChange={handleMedicalHistoryChange} placeholder="Software Engineer" />
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>Marital Status</FormLabel>
                                        <FormSelect name="maritalStatus" value={medicalHistory.maritalStatus} onChange={handleMedicalHistoryChange}>
                                            <option value="">Select status</option>
                                            <option value="Single">Single</option>
                                            <option value="Married">Married</option>
                                            <option value="Divorced">Divorced</option>
                                            <option value="Widowed">Widowed</option>
                                        </FormSelect>
                                    </FormGroup>

                                </FormGrid>
                            </FormSection>

                            <FormSection>
                                <SectionTitle>Medical Conditions & Allergies</SectionTitle>
                                <FormGrid>
                                    <FormGroup>
                                        <FormLabel>Allergies</FormLabel>
                                        <TextArea name="allergies" value={medicalHistory.allergies} onChange={handleMedicalHistoryChange} placeholder="Enter any allergies..." />
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>Pre-existing Conditions</FormLabel>
                                        <TextArea
                                            name="preExistingConditions"
                                            value={medicalHistory.preExistingConditions}
                                            onChange={handleMedicalHistoryChange}
                                            placeholder="Enter any pre-existing conditions..."
                                        />
                                    </FormGroup>
                                </FormGrid>
                            </FormSection>

                            <FormSection>
                                <SectionTitle>Treatments & History</SectionTitle>
                                <FormGrid>
                                    <FormGroup>
                                        <FormLabel>Regular Medication</FormLabel>
                                        <TextArea
                                            name="regularMedication"
                                            value={medicalHistory.regularMedication}
                                            onChange={handleMedicalHistoryChange}
                                            placeholder="Lisinopril 10mg daily, Metformin 500mg twice daily"
                                        />
                                    </FormGroup>

                                    <FormGroup>
                                        <FormLabel>Surgery History</FormLabel>
                                        <TextArea name="surgeryHistory" value={medicalHistory.surgeryHistory} onChange={handleMedicalHistoryChange} placeholder="Appendectomy - 2015" />
                                    </FormGroup>
                                </FormGrid>
                            </FormSection>

                            <FormSection>
                                <SectionTitle>Lifestyle & Risk Factors</SectionTitle>
                                <FormGroup fullWidth>
                                    <FormLabel>Select all applicable risk factors</FormLabel>
                                    <RiskFactorsGrid>
                                        {[
                                            "Tobacco Use (Past)",
                                            "Tobacco Use (Current)",
                                            "Alcohol Use (Past)",
                                            "Alcohol Use (Current)",
                                            "Occupational Hazard",
                                            "Environmental Exposure",
                                            "Others",
                                        ].map((factor) => (
                                            <RiskFactorOption key={factor} selected={medicalHistory.riskFactors.includes(factor)}>
                                                <RiskFactorCheckbox type="checkbox" checked={medicalHistory.riskFactors.includes(factor)} onChange={() => toggleRiskFactor(factor)} />
                                                <RiskFactorLabel>{factor}</RiskFactorLabel>
                                            </RiskFactorOption>
                                        ))}
                                    </RiskFactorsGrid>
                                </FormGroup>

                                <FormGroup fullWidth>
                                    <FormLabel>Other Risk Factors</FormLabel>
                                    <TextArea
                                        name="otherRiskFactors"
                                        value={medicalHistory.otherRiskFactors}
                                        onChange={handleMedicalHistoryChange}
                                        placeholder="e.g., Stress, Family history of hypertension"
                                    />
                                </FormGroup>
                            </FormSection>
                        </>
                    )} */}

                    {currentStep === 2 && (
                        <>
                            <FormSection>
                                <SectionTitle>Patient Information</SectionTitle>

                                <FormRow threeColumns={requiresAppointment}>
                                    <FormGroup>
                                        <FormLabel>
                                            Practitioner<RequiredAsterisk>*</RequiredAsterisk>
                                        </FormLabel>

                                        <Select
                                            options={doctorOptions}

                                            // value={
                                            //     filteredDoctors
                                            //         .map((doc) => ({
                                            //             label: `${doc.doctor_name} (${doc.room_name}) ${doc.from_time.slice(0, 5)} - ${doc.to_time.slice(0, 5)}`,
                                            //             value: doc.doctor_id,
                                            //         }))
                                            //         .find((opt) => opt.value === billingData.referringPractitioner) || null
                                            // }

                                            value={
                                                doctorOptions.find(
                                                    (opt) => opt.value === billingData.referringPractitioner
                                                ) || null
                                            }

                                            onChange={async (selected) => {
                                                const doctorId = selected ? selected.value : "";

                                                setBillingData((prev) => ({
                                                    ...prev,
                                                    referringPractitioner: doctorId,
                                                }));

                                                if (!doctorId) return;

                                                const fee = await fetchDoctorFee(formData.company, doctorId);

                                                if (!fee) return;

                                                setItems((prevItems) =>
                                                    prevItems.map((item) => {
                                                        if (item.item === "STO-ITEM-2025-00539") {
                                                            const qty = parseFloat(item.qty) || 1;

                                                            return {
                                                                ...item,
                                                                rate: fee,
                                                                amount: fee * qty,
                                                            };
                                                        }
                                                        return item;
                                                    })
                                                );
                                            }}

                                            // placeholder={
                                            //     loadingDoctors
                                            //         ? "Loading available doctors..."
                                            //         : filteredDoctors.length === 0
                                            //             ? "No doctors available for selected date"
                                            //             : "Select available doctor..."
                                            // }

                                            placeholder={
                                                requiresAppointment
                                                    ? loadingDoctors
                                                        ? "Loading available doctors..."
                                                        : doctorOptions.length === 0
                                                            ? "No doctors available for selected date"
                                                            : "Select available doctor..."
                                                    : doctorOptions.length === 0
                                                        ? "No doctors found"
                                                        : "Select doctor..."
                                            }

                                            isSearchable
                                            isClearable
                                            required
                                        />
                                    </FormGroup>

                                    {requiresAppointment && (
                                        <>
                                            <FormGroup>
                                                <FormLabel>
                                                    Appointment Date<RequiredAsterisk>*</RequiredAsterisk>
                                                </FormLabel>
                                                <FormInput
                                                    type="date"
                                                    name="appointmentDate"
                                                    value={formData.appointmentDate}
                                                    min={new Date().toISOString().split("T")[0]}
                                                    onChange={handleInputChange}
                                                    required
                                                />
                                            </FormGroup>

                                            <FormGroup>
                                                <FormLabel>
                                                    Appointment Time<RequiredAsterisk>*</RequiredAsterisk>
                                                </FormLabel>
                                                <FormInput
                                                    type="time"
                                                    name="appointmentTime"
                                                    value={formData.appointmentTime || ""}
                                                    onChange={handleInputChange}
                                                    required
                                                />
                                            </FormGroup>
                                        </>
                                    )}
                                </FormRow>
                            </FormSection>

                            <ItemsSection>
                                <ItemsHeader>
                                    <ItemsTitle>Items</ItemsTitle>

                                    <ItemButtons style={{ display: "flex", alignItems: "center", gap: "16px" }}>

                                        <IconButton type="button" onClick={addItem}>
                                            <Plus />
                                        </IconButton>
                                    </ItemButtons>
                                </ItemsHeader>

                                <ItemsTable>
                                    <TableHead>
                                        <TableRow>
                                            <TableHeader>No.</TableHeader>
                                            <TableHeader>Item</TableHeader>
                                            <TableHeader>Item Name</TableHeader>
                                            <TableHeader>Qty</TableHeader>
                                            <TableHeader>Rate</TableHeader>
                                            <TableHeader>Amount</TableHeader>
                                            <TableHeader></TableHeader>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {items.map((item, index) => (
                                            <TableRow key={index}>
                                                <TableCell>{index + 1}</TableCell>
                                                <TableCell>
                                                    <ItemSearchWrapper>
                                                        {item.item ? (
                                                            <ItemInput type="text" value={item.item} disabled />) : (
                                                            <>
                                                                {/* <ItemInput
                                                                    type="text"
                                                                    placeholder="Search item..."
                                                                    value={itemSearchIndex === index ? itemSearch : ""}
                                                                    onChange={(e) => {
                                                                        setItemSearchIndex(index);
                                                                        setItemSearch(e.target.value);
                                                                    }}
                                                                    onFocus={() => {
                                                                        setItemSearchIndex(index);
                                                                        if (itemSearch.length >= 2)
                                                                            setShowItemResults(true);
                                                                    }}
                                                                    onBlur={() => setTimeout(() => setShowItemResults(false), 200)}
                                                                /> */}
                                                                <ItemInput
                                                                    type="text"
                                                                    placeholder="Search item..."
                                                                    value={itemSearchIndex === index ? itemSearch : ""}
                                                                    onChange={(e) => {
                                                                        setItemSearchIndex(index);
                                                                        setItemSearch(e.target.value);
                                                                        setActiveResultIndex(-1); // reset selection
                                                                    }}
                                                                    onKeyDown={(e) => {
                                                                        if (!showItemResults) return;

                                                                        if (e.key === "ArrowDown") {
                                                                            e.preventDefault();
                                                                            setActiveResultIndex((prev) =>
                                                                                prev < itemResults.length - 1 ? prev + 1 : 0
                                                                            );
                                                                        }

                                                                        if (e.key === "ArrowUp") {
                                                                            e.preventDefault();
                                                                            setActiveResultIndex((prev) =>
                                                                                prev > 0 ? prev - 1 : itemResults.length - 1
                                                                            );
                                                                        }

                                                                        if (e.key === "Enter") {
                                                                            e.preventDefault();
                                                                            if (activeResultIndex >= 0) {
                                                                                handleItemSelect(itemResults[activeResultIndex], index);
                                                                            }
                                                                        }
                                                                    }}
                                                                    onFocus={() => {
                                                                        setItemSearchIndex(index);
                                                                        if (itemSearch.length >= 2) setShowItemResults(true);
                                                                    }}
                                                                    onBlur={() => setTimeout(() => setShowItemResults(false), 200)}
                                                                />

                                                                {/* {showItemResults && itemSearchIndex === index && (
                                                                    <SearchResults>
                                                                        {itemResults.length > 0 ? (itemResults.map((itemResult, idx) => (
                                                                            <SearchResultItem key={idx} onMouseDown={() => handleItemSelect(itemResult, index)} >
                                                                                {itemResult.description || ""}
                                                                            </SearchResultItem>))) : (<SearchResultEmpty> {searchingItem ? "Searching..." : "No items found"}

                                                                            </SearchResultEmpty>
                                                                        )}
                                                                    </SearchResults>)} */}
                                                                {showItemResults && itemSearchIndex === index && (
                                                                    <SearchResults>
                                                                        {itemResults.length > 0 ? (itemResults.map((itemResult, idx) => (
                                                                            <SearchResultItem
                                                                                key={idx}
                                                                                ref={(el) => (resultRefs.current[idx] = el)}
                                                                                onMouseDown={() => handleItemSelect(itemResult, index)}
                                                                                style={{
                                                                                    backgroundColor: activeResultIndex === idx ? "#eee" : "white",
                                                                                    cursor: "pointer",
                                                                                }}
                                                                            >
                                                                                {itemResult.description || ""}
                                                                            </SearchResultItem>)))
                                                                            : (<SearchResultEmpty> {searchingItem ? "Searching..." : "No items found"}

                                                                            </SearchResultEmpty>
                                                                            )}
                                                                    </SearchResults>)
                                                                }
                                                            </>
                                                        )}
                                                    </ItemSearchWrapper>
                                                </TableCell>
                                                <TableCell>
                                                    <ItemInput type="text" value={item.itemName} disabled />
                                                </TableCell>
                                                <TableCell>
                                                    <ItemInput type="number" value={item.qty} onChange={(e) => handleItemChange(index, "qty", e.target.value)} />
                                                </TableCell>
                                                <TableCell>
                                                    <ItemInput type="number" step="0.01" value={item.rate} onChange={(e) => handleItemChange(index, "rate", e.target.value)} />
                                                </TableCell>
                                                <TableCell>{item.amount.toFixed(2)}</TableCell>
                                                <TableCell>
                                                    <DeleteItemButton type="button" onClick={() => removeItem(index)}>
                                                        <X />
                                                    </DeleteItemButton>
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </ItemsTable>

                                <ItemFooter>
                                    <FooterItem>
                                        <FooterLabel>Discount %</FooterLabel>
                                        <DiscountInput type="number" name="discountPercent" value={billingData.discountPercent} onChange={handleBillingChange} />
                                    </FooterItem>
                                    <FooterItem>
                                        <FooterLabel>Total Qty:</FooterLabel>
                                        <FooterValue>{calculateTotals().totalQty}</FooterValue>
                                    </FooterItem>
                                    <FooterItem>
                                        <FooterLabel>Total:</FooterLabel>
                                        <FooterValue>{calculateTotals().grossTotal.toFixed(2)}</FooterValue>
                                    </FooterItem>
                                </ItemFooter>
                            </ItemsSection>

                            <BottomSection>
                                <CalculationCard>
                                    <CardTitle>Calculation</CardTitle>
                                    <CalculationRow>
                                        <CalculationLabel>Gross Total</CalculationLabel>
                                        <CalculationValue>{calculateTotals().grossTotal.toFixed(2)}</CalculationValue>
                                    </CalculationRow>
                                    <CalculationRow>
                                        <CalculationLabel>Discount Amount</CalculationLabel>
                                        <CalculationValue>{calculateTotals().discountAmount.toFixed(2)}</CalculationValue>
                                    </CalculationRow>
                                    <CalculationRow>
                                        <CalculationLabel bold>Net Total (INR)</CalculationLabel>
                                        <CalculationValue bold highlight>
                                            {calculateTotals().netTotal.toFixed(2)}
                                        </CalculationValue>
                                    </CalculationRow>
                                </CalculationCard>

                                <CalculationCard>
                                    <CardTitle>Payment</CardTitle>
                                    <FormGroup>
                                        <FormLabel>Payment Type</FormLabel>
                                        <FormSelect name="mode_of_payment" value={billingData.mode_of_payment} onChange={handleBillingChange}>
                                            <option value="">Select payment type</option>
                                            <option value="Cash">Cash</option>
                                            <option value="UPI">UPI</option>
                                        </FormSelect>
                                    </FormGroup>
                                    {billingData.mode_of_payment === "UPI" && (
                                        <>
                                            {/* Dummy QR */}
                                            <div style={{ marginTop: "16px", textAlign: "center" }}>
                                                <img
                                                    src={paymentQR}
                                                    alt="UPI QR"
                                                    style={{ width: "200px", height: "200px" }}
                                                />
                                            </div>

                                            <FormGroup>
                                                <FormLabel>UPI Reference No<RequiredAsterisk>*</RequiredAsterisk></FormLabel>
                                                <FormInput
                                                    type="text"
                                                    name="reference_no"
                                                    value={billingData.reference_no || ""}
                                                    onChange={handleBillingChange}
                                                    required={billingData.mode_of_payment === "UPI"}
                                                />
                                            </FormGroup>

                                            <FormGroup>
                                                <FormLabel>Reference Date<RequiredAsterisk>*</RequiredAsterisk></FormLabel>
                                                <FormInput
                                                    type="date"
                                                    name="reference_date"
                                                    value={billingData.reference_date || ""}
                                                    onChange={handleBillingChange}
                                                    required={billingData.mode_of_payment === "UPI"}
                                                />
                                            </FormGroup>
                                        </>
                                    )}
                                </CalculationCard>
                            </BottomSection>
                        </>
                    )}

                    {currentStep === 1 && (
                        <ActionButtons>
                            <BackButton type="button" onClick={() => navigate("/patients")}>
                                Back
                            </BackButton>
                            <NextButton type="submit">Next</NextButton>
                        </ActionButtons>
                    )}

                    {/* {currentStep === 2 && (
                        <ActionButtons>
                            <BackButton type="button" onClick={handlePreviousStep}>
                                Back
                            </BackButton>
                            <NextButton type="submit">Next</NextButton>
                        </ActionButtons>
                    )} */}

                    {currentStep === 2 && (
                        <ActionButtons>
                            <BackButton type="button" onClick={handlePreviousStep}>
                                Back
                            </BackButton>
                            <NextButton
                                type="button"
                                onClick={() => {
                                    if (formRef.current.checkValidity()) {
                                        setShowConfirmModal(true);
                                    } else {
                                        formRef.current.reportValidity(); // shows validation errors
                                    }
                                }}
                                disabled={isSubmitting}
                            >
                                {isSubmitting ? "Submitting..." : "Submit and Send to Doctor"}
                            </NextButton>
                        </ActionButtons>
                    )}

                </form>

                <AadhaarScanner
                    isOpen={isAadhaarScannerOpen}
                    onClose={() => setIsAadhaarScannerOpen(false)}
                    onDataExtracted={handleAadhaarDataExtracted}
                />
                <AadhaarOCRScanner
                    isOpen={isAadhaarOCRScannerOpen}
                    onClose={() => setIsAadhaarOCRScannerOpen(false)}
                    onDataExtracted={handleAadhaarDataExtracted}
                />

                {showConfirmModal && (
                    <div style={modalOverlayStyle}>
                        <div style={modalStyle}>
                            <h3 style={{ marginBottom: "12px", }}>Confirm Submission</h3>
                            <p style={{ marginBottom: "12px", fontSize: "14px" }}>Are you sure you want to submit and send to doctor?</p>

                            <div style={{ display: "flex", justifyContent: "flex-end", gap: "12px", marginTop: "20px" }}>
                                <BackButton onClick={handleCancelSubmit}>Cancel</BackButton>

                                <NextButton onClick={handleConfirmSubmit}>
                                    Submit
                                </NextButton>
                            </div>
                        </div>
                    </div>
                )}
            </RegistrationContainer>
        </Layout>
    );
};

export default OPDPatientRegistration;
